namespace Direct4Me.Repository.Enums;

public enum LoginType
{
    Default,
    Face
}