namespace Direct4Me.Repository.Enums;

public enum UnlockType
{
    Nfc,
    QrCode
}