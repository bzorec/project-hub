window.Blazor = {
    getBoundingClientRect: function (element) {
        return element.getBoundingClientRect();
    }
};
