namespace Direct4Me.Blazor.Shared;

public partial class MainLayout
{
}