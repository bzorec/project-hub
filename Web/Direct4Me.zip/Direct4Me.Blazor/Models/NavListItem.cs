namespace Direct4Me.Blazor.Models;

public class NavListItem
{
    public string Name { get; set; } = null!;
    public string Href { get; set; } = null!;
}