namespace Direct4Me.Blazor.Models;

public enum NavigationType
{
    Login,
    Default
}