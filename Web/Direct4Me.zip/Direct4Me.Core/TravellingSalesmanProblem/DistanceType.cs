namespace Direct4Me.Core.TravellingSalesmanProblem;

public enum DistanceType
{
    Euclidean,
    Weighted
}